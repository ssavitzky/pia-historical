// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * PlusString is a binary function object that
 * returns the concatenation of the operands as strings.
 * <p>
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 */

public final class PlusString implements BinaryFunction
  {
  /**
   * Return the concatenation of the two operands.
   * @return first.toString() + second.toString()
   */
  public Object execute( Object first, Object second )
    {
    return first.toString() + second.toString();
    }
  }
