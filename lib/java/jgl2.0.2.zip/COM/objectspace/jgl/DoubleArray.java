// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

import java.util.Enumeration;

/**
 * DoubleArray allows a native array of doubles to be accessed like a Container.
 * It is particularly useful for applying generic algorithms like Sorting.sort()
 * to a native array.
 * <p>
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 */

public class DoubleArray extends ArrayAdapter
  {
  double myArray[];

  public DoubleArray()
    {
    myArray = new double[ 0 ];
    }

  public DoubleArray( double array[] )
    {
    myArray = array;
    }

  public DoubleArray( DoubleArray array )
    {
    myArray = array.myArray;
    }

  /**
   * Return a shallow copy of myself.
   */
  public synchronized Object clone()
    {
    return new DoubleArray( this );
    }

  /**
   * Return a string that describes me.
   */
  public synchronized String toString()
    {
    return Printing.toString( this, "double[]" );
    }

  /**
   * Return true if I'm equal to a specified object.
   * @param object The object to compare myself against.
   * @return true if I'm equal to the specified object.
   */
  public boolean equals( Object object )
    {
    return object instanceof DoubleArray && equals( (DoubleArray)object );
    }

  /**
   * Return true if I contain the same items in the same order as
   * another DoubleArray. Use equals() to compare the individual elements.
   * @param array The DoubleArray to compare myself against.
   * @return true if I'm equal to the specified object.
   */
  public synchronized boolean equals( DoubleArray object )
    {
    synchronized( object )
      {
      return Comparing.equal( this, object );
      }
    }

  /**
   * Return the number of objects that I contain.
   */
  public int size()
    {
    return myArray.length;
    }

  /**
   * Return the maximum number of objects that I can contain.
   */
  public int maxSize()
    {
    return myArray.length;
    }

  /**
   * Return an Enumeration of my components.
   */
  public synchronized Enumeration elements()
    {
    return DoubleIterator.begin( myArray, this );
    }

  /**
   * Return an iterator positioned at my first item.
   */
  public synchronized ForwardIterator start()
    {
    return DoubleIterator.begin( myArray, this );
    }

  /**
   * Return an iterator positioned immediately after my last item.
   */
  public synchronized ForwardIterator finish()
    {
    return DoubleIterator.end( myArray, this );
    }

  /**
   * Return the integer at the specified index as a Double object.
   * @param index The index.
   */
  public synchronized Object at( int index )
    {
    return new Double( myArray[index] );
    }

  /**
   * Set the object at a specified index.  The object must be a Double
   * @param index The index.
   * @param object The object to place at the specified index.
   * @exception java.lang.ClassCastException if object is not a Double
   * @exception java.lang.IndexOutOfBoundsException if object is not a Double
   */
  public synchronized void put( int index, Object object )
    {
    myArray[index] = ((Double)object).doubleValue();
    }
  }
