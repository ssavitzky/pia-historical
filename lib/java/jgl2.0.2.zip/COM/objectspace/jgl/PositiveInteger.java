// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * PositiveInteger is a unary predicate that returns true if its operand is positive.
 * <p>
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 * @deprecated
 * @see COM.objectspace.jgl.PositiveNumber
 */

public final class PositiveInteger implements UnaryPredicate
  {
  /**
   * Return true if the operand is greater than zero.
   * @param object The operand, which must be an Integer.
   * @return object > 0
   */
  public boolean execute( Object object )
    {
    return ((Integer) object).intValue() > 0;
    }
  }
