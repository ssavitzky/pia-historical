// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * NegativeInteger is a unary predicate that returns true if its operand is negative.
 * <p>
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 * @deprecated
 * @see COM.objectspace.jgl.NegativeNumber
 */

public final class NegativeInteger implements UnaryPredicate
  {
  /**
   * Return true if the operand is less than zero.
   * @param object The operand, which must be an Integer.
   * @return object < 0
   */
  public boolean execute( Object object )
    {
    return ((Integer) object).intValue() < 0;
    }
  }
