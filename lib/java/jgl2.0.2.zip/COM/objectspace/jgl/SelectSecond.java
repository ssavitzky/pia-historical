// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * SelectSecond is a unary function that assumes that its operand is a Pair and returns
 * its second instance variable.
 * <p>
 * @see COM.objectspace.jgl.SelectFirst
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 */

public final class SelectSecond implements UnaryFunction
  {
  /**
   * Return the second instance variable of my operand.
   * @param object The operand, which must be an instance of Pair.
   * @return object.second
   */
  public Object execute( Object object )
    {
    return ((Pair) object).second;
    }
  }
