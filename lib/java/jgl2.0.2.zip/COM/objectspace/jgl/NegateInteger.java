// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * NegateInteger is a unary function object that assumes that its operand is an instance of
 * Integer and returns its negation.
 * <p>
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 * @deprecated
 * @see COM.objectspace.jgl.NegateNumber
 */

public final class NegateInteger implements UnaryFunction
  {
  /**
   * Return the negation of my operand.
   * @param object The operand, which must be an instance of Integer.
   * @return -object
   */
  public Object execute( Object object )
    {
    return new Integer( -((Integer) object).intValue() );
    }
  }
