// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * LengthString is a unary function that returns the length of
 * its operand as a string.
 * <p>
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 */

public final class LengthString implements UnaryFunction
  {
  /**
   * Return the length of my operand's string as an Integer.
   * @param object The operand
   * @return The length of the operand.toString().
   */
  public Object execute( Object object )
    {
    return new Integer( object.toString().length() );
    }
  }
