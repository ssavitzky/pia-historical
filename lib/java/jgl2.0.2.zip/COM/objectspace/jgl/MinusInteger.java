// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * MinusInteger is a binary function object that assumes that both of its operands are
 * instances of Integer and returns the second operand subtraced from the first operand.
 * <p>
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 * @deprecated
 * @see COM.objectspace.jgl.MinusNumber
 */

public final class MinusInteger implements BinaryFunction
  {
  /**
   * Return the result of subtracting the second operand from the first operand.
   * @param first The first operand, which must be an instance of Integer.
   * @param second The second operand, which must be an instance of Integer.
   * @return first - second
   */
  public Object execute( Object first, Object second )
    {
    return new Integer( ((Integer) first).intValue() - ((Integer) second).intValue() );
    }
  }
