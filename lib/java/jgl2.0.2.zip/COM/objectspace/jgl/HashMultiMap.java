// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

import java.util.Dictionary;
import java.util.Enumeration;

/**
 * A HashMultiMap is an associative container that manages a set of key/value pairs.
 * A pair is stored in a hashing structure based on the hash code of its key, which
 * is obtained by using the standard hashCode() function. Keys are matched using
 * a BinaryPredicate which is EqualTo() by default. Duplicates keys are allowed.
 * <p>
 * A HashMultiMap is useful for implementing a collection of one-to-many
 * mappings.
 * <p>
 * Insertion can invalidate iterators.
 * <p>
 * Removal can invalidate iterators.
 * <p>
 * @see COM.objectspace.jgl.HashMap
 * @see COM.objectspace.jgl.examples.HashMapExamples
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 * @deprecated
 * @see COM.objectspace.jgl.HashMap
 */

public class HashMultiMap extends HashMap
  {
  /**
   * Construct myself to be an empty HashMultiMap that compares key using equals().
   */
  public HashMultiMap()
    {
    super( new EqualTo(), true, DEFAULT_SIZE, DEFAULT_RATIO );
    }

  /**
   * Construct myself to be an empty HashMultiMap that compares keys using the specified
   * binary predicate.
   * @param comparator The predicate for comparing keys.
   */
  public HashMultiMap( BinaryPredicate comparator )
    {
    super( comparator, true, DEFAULT_SIZE, DEFAULT_RATIO );
    }

  /**
   * Construct myself to be an empty HashMultiMap that compares keys using the specified
   * binary predicate. The initial buckets and load ratio must also be specified.
   * @param comparator The predicate for comparing keys.
   * @param capacity The initial number of hash buckets to reserve.
   * @param loadRatio The maximum load ratio.
   */
  public HashMultiMap( BinaryPredicate comparator, int capacity, float loadRatio )
    {
    super( comparator, true, capacity, loadRatio );
    }

  /**
   * Construct myself to be a shallow copy of an existing HashMultiMap.
   * @param map The HashMultiMap to copy.
   */
  public HashMultiMap( HashMultiMap map )
    {
    copy( map );
    }

  /**
   * Return a shallow copy of myself.
   */
  public synchronized Object clone()
    {
    return new HashMultiMap( this );
    }

  /**
   * Return a string that describes me.
   */
  public synchronized String toString()
    {
    return Printing.toString( this, "HashMultiMap" );
    }

  /**
   * Return true if I'm equal to another object.
   * @param object The object to compare myself against.
   */
  public boolean equals( Object object )
    {
    return object instanceof HashMultiMap && equals( (HashMultiMap) object );
    }

  /**
   * Return true if I contain exactly the same key/value pairs as another HashMultiMap.
   * Use equals() to compare values.
   * @param map The HashMultiMap to compare myself against.
   */
  public synchronized boolean equals( HashMultiMap map )
    {
    return super.equals( map );
    }

  /**
   * Swap my contents with another HashMultiMap.
   * @param map The HashMultiMap that I will swap my contents with.
   */
  public synchronized void swap( HashMultiMap map )
    {
    super.swap( map );
    }
  }
