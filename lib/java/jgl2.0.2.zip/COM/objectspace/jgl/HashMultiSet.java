// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

import java.util.Enumeration;

/**
 * A HashMultiSet is a container that is optimized for fast associative lookup. Items are
 * matched using a BinaryPredicate which is EqualTo() by default. When an item is
 * inserted into a HashMultiSet, it is stored in a data structure that allows the item
 * to be found very quickly. Items are stored in buckets based on their hash value,
 * computed using the standard function hashCode().
 * A HashMultiSet may contain items that match.
 * <p>
 * HashMultiSets are useful when fast associate lookup is important, and when index-based lookup is
 * unnecessary.
 * <p>
 * Insertion can invalidate iterators.
 * <p>
 * Removal can invalidate iterators.
 * <p>
 * @see COM.objectspace.jgl.SetOperations
 * @see COM.objectspace.jgl.HashSet
 * @see COM.objectspace.jgl.examples.HashSetExamples
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 * @deprecated
 * @see COM.objectspace.jgl.HashSet
 */

public class HashMultiSet extends HashSet
  {
  /**
   * Construct myself to be an empty HashMultiSet that compares objects using equals().
   */
  public HashMultiSet()
    {
    super( new EqualTo(), true, DEFAULT_SIZE, DEFAULT_RATIO );
    }

  /**
   * Construct myself to be an empty HashMultiSet that compares objects using the specified
   * binary predicate.
   * @param comparator The predicate for comparing objects.
   */
  public HashMultiSet( BinaryPredicate comparator )
    {
    super( comparator, true, DEFAULT_SIZE, DEFAULT_RATIO );
    }

  /**
   * Construct myself to be an empty HashMultiSet that compares objects using the specified
   * binary predicate. The initial capacity and load ratio must also be specified.
   * @param comparator The predicate for comparing objects.
   * @param capacity The initial number of hash buckets to reserve.
   * @param loadRatio The maximum load ratio.
   */
  public HashMultiSet( BinaryPredicate comparator, int capacity, float loadRatio  )
    {
    super( comparator, true, capacity, loadRatio );
    }

  /**
   * Construct myself to be a shallow copy of an existing HashMultiSet.
   * @param set The HashMultiSet to copy.
   */
  public HashMultiSet( HashMultiSet set )
    {
    copy( set );
    }

  /**
   * Return a shallow copy of myself.
   */
  public synchronized Object clone()
    {
    return new HashMultiSet( this );
    }

  /**
   * Become a shallow copy of an existing HashMultiSet.
   * @param set The HashMultiSet that I shall become a shallow copy of.
   */
  public synchronized void copy( HashMultiSet set )
    {
    super.copy( set );
    }

  /**
   * Return a string that describes me.
   */
  public synchronized String toString()
    {
    return Printing.toString( this, "HashMultiSet" );
    }

  /**
   * Return true if I'm equal to another object.
   * @param object The object to compare myself against.
   */
  public boolean equals( Object object )
    {
    return object instanceof HashMultiSet && equals( (HashMultiSet)object );
    }

  /**
   * Return true if I contain exactly the same items as another HashMultiSet.
   * Use equals() to compare the individual elements.
   * @param set The HashMultiSet to compare myself against.
   */
  public synchronized boolean equals( HashMultiSet set )
    {
    return super.equals( set );
    }

  /**
   * Swap my contents with another HashMultiSet.
   * @param set The HashMultiSet that I will swap my contents with.
   */
  public synchronized void swap( HashMultiSet set )
    {
    super.swap( set );
    }
  }
