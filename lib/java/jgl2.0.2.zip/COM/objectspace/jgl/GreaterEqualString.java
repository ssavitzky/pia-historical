// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * GreaterEqualString is a binary predicate that
 * returns true if the first operand as a string is greater
 * than or equal to the second operand as a string.
 * <p>
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 */

public final class GreaterEqualString implements BinaryPredicate
  {
  /**
   * Return true if the first operand is greater than or equal to the second operand.
   * @return first.toString() >= second.toString()
   */
  public boolean execute( Object first, Object second )
    {
    return first.toString().compareTo( second.toString() ) >= 0;
    }
  }
