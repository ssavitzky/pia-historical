// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * PlusInteger is a binary function object that assumes that both of its operands are
 * instances of Integer and returns the first operand added to the second operand.
 * <p>
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 * @deprecated
 * @see COM.objectspace.jgl.PlusNumber
 */

public final class PlusInteger implements BinaryFunction
  {
  /**
   * Return the result of adding the first operand to the second operand.
   * @param first The first operand, which must be an instance of Integer.
   * @param second The second operand, which must be an instance of Integer.
   * @return first + second
   */
  public Object execute( Object first, Object second )
    {
    return new Integer( ((Integer) first).intValue() + ((Integer) second).intValue() );
    }
  }
