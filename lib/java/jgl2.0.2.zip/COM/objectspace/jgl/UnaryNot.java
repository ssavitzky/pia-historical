// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * UnaryNot is a unary predicate that returns true if the result of executing
 * a unary predicate on its operands is false.
 * <p>
 * @see COM.objectspace.jgl.BinaryNot
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 */

public final class UnaryNot implements UnaryPredicate
  {
  UnaryPredicate myPredicate;

  /**
   * Construct myself with a single unary predicate object.
   * @param predicate The unary predicate object, which should be a predicate.
   */
  public UnaryNot( UnaryPredicate predicate )
    {
    myPredicate = predicate;
    }

  /**
   * Perform my unary predicate on the operand and return true if the predicate
   * returns false.
   * @param object The operand.
   * @return !predicate( object )
   */
  public boolean execute( Object object )
    {
    return !myPredicate.execute( object );
    }
  }
