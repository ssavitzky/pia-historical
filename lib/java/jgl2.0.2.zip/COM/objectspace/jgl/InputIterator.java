// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

import java.util.Enumeration;

/**
 * InputIterator is the interface of all iterators that can read one
 * item at a time in a forward direction. InputIterator is an extension
 * of the java.lang.Enumeration class.
 * <p>
 * @see COM.objectspace.jgl.OutputIterator
 * @see java.util.Enumeration
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 */

public interface InputIterator extends Enumeration, Cloneable
  {
  /**
   * Return true if I'm positioned at the first item of my input stream.
   */
  public boolean atBegin();

  /**
   * Return true if I'm positioned after the last item in my input stream.
   */
  public boolean atEnd();

  /**
   * Return the object at my current position.
   */
  public Object get();

  /**
   * Advance by one.
   */
  public void advance();

  /**
   * Advance by a specified amount.
   * @param n The amount to advance.
   */
  public void advance( int n );

  /**
   * Return a clone of myself.
   */
  public Object clone();
  }
