// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

import java.io.Serializable;

/**
 * An SListIterator is a forward iterator that allows you to iterate through
 * the contents of an SList.
 * <p>
 * @see COM.objectspace.jgl.ForwardIterator
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 */

public final class SListIterator implements ForwardIterator, Serializable
  {
  SList mySList;
  SList.SListNode myNode;

  /**
   * Construct myself to be an iterator with no associated data structure or position.
   */
  public SListIterator()
    {
    }

  /**
   * Construct myself to be positioned at a particular node in a specified list.
   * @param list My associated list.
   * @param node My associated node.
   */
  SListIterator( SList list, SList.SListNode node )
    {
    mySList = list;
    myNode = node;
    }

  /**
   * Construct myself to be a copy of an existing iterator.
   * @param iterator The iterator to copy.
   */
  public SListIterator( SListIterator iterator )
    {
    mySList = iterator.mySList;
    myNode = iterator.myNode;
    }

  /**
   * Return a clone of myself.
   */
  public Object clone()
    {
    return new SListIterator( this );
    }

  /**
   * Return true if a specified object is the same kind of iterator as me
   * and is positioned at the same element.
   * @param object Any object.
   */
  public boolean equals( Object object )
    {
    return object instanceof SListIterator && equals( (SListIterator) object );
    }

  /**
   * Return true if iterator is positioned at the same element as me.
   * @param iterator The iterator to compare myself against.
   */
  public boolean equals( SListIterator iterator )
    {
    return myNode == iterator.myNode;
    }

  /**
   * Return true if I'm positioned at the first item of my input stream.
   */
  public boolean atBegin()
    {
    return myNode == mySList.myHead;
    }

  /**
   * Return true if I'm positioned after the last item in my input stream.
   */
  public boolean atEnd()
    {
    return myNode == null;
    }

  /**
   * Return true if there are more elements in my input stream.
   */
  public boolean hasMoreElements()
    {
    return myNode != null;
    }

  /**
   * Advance by one.
   */
  public void advance()
    {
    myNode = myNode.next;
    }

  /**
   * Advance by a specified amount.
   * @param n The amount to advance.
   * @exception COM.objectspace.jgl.InvalidOperationException If the parameter is less than zero.
   */
  public void advance( int n )
    {
    if ( n < 0 )
      throw new InvalidOperationException( "Attempt to advance a ForwardIterator in the wrong direction." );
    while ( n-- > 0 )
      myNode = myNode.next;
    }

  /**
   * Return the next element in my input stream.
   */
  public Object nextElement()
    {
    Object object = myNode.object;
    myNode = myNode.next;
    return object;
    }

  /**
   * Return the object at my current position.
   */
  public Object get()
    {
    return myNode.object;
    }

  /**
   * Set the object at my current position to a specified value.
   * @param object The object to be written at my current position.
   */
  public void put( Object object )
    {
    myNode.object = object;
    }

  /**
   * Return the distance from myself to another iterator.
   * I should be before the specified iterator.
   * @param iterator The iterator to compare myself against.
   */
  public int distance( ForwardIterator iterator )
    {
    return distance( myNode, ((SListIterator) iterator).myNode );
    }

  /**
   * Return my current index.
   */
  public int index()
    {
    return distance( mySList.myHead, myNode );
    }

  private int distance( SList.SListNode from, SList.SListNode to )
    {
    int n = 0;

    while ( from != to )
      {
      ++n;
      from = from.next;
      }

    return n;
    }

  /**
   * Return my associated SList.
   */
  public Container getContainer()
    {
    return mySList;
    }
  }
