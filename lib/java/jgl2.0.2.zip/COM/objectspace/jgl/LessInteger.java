// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * LessInteger is a binary predicate that assumes that both of its operands are
 * instances of Integer and returns true if the first operand is less than the second operand.
 * <p>
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 * @deprecated
 * @see COM.objectspace.jgl.LessNumber
 */

public class LessInteger implements BinaryPredicate
  {
  /**
   * Return true if the first operand is less than the second operand.
   * @param first The first operand, which must be an instance of Integer.
   * @param second The second operand, which must be an instance of Integer.
   * @return first < second
   */
  public boolean execute( Object first, Object second )
    {
    return ((Integer) first).intValue() < ((Integer) second).intValue();
    }
  }
