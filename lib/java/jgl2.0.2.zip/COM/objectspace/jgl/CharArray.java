// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

import java.util.Enumeration;

/**
 * CharArray allows a native array of chars to be accessed like a Container.
 * It is particularly useful for applying generic algorithms like Sorting.sort()
 * to a native array.
 * <p>
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 */

public class CharArray extends ArrayAdapter
  {
  char myArray[];

  public CharArray()
    {
    myArray = new char[ 0 ];
    }

  public CharArray( char array[] )
    {
    myArray = array;
    }

  public CharArray( CharArray array )
    {
    myArray = array.myArray;
    }

  /**
   * Return a shallow copy of myself.
   */
  public synchronized Object clone()
    {
    return new CharArray( this );
    }

  /**
   * Return a string that describes me.
   */
  public synchronized String toString()
    {
    return Printing.toString( this, "char[]" );
    }

  /**
   * Return true if I'm equal to a specified object.
   * @param object The object to compare myself against.
   * @return true if I'm equal to the specified object.
   */
  public boolean equals( Object object )
    {
    return object instanceof CharArray && equals( (CharArray)object );
    }

  /**
   * Return true if I contain the same items in the same order as
   * another CharArray. Use equals() to compare the individual elements.
   * @param array The CharArray to compare myself against.
   * @return true if I'm equal to the specified object.
   */
  public synchronized boolean equals( CharArray object )
    {
    synchronized( object )
      {
      return Comparing.equal( this, object );
      }
    }

  /**
   * Return the number of objects that I contain.
   */
  public int size()
    {
    return myArray.length;
    }

  /**
   * Return the maximum number of objects that I can contain.
   */
  public int maxSize()
    {
    return myArray.length;
    }

  /**
   * Return an Enumeration of my components.
   */
  public synchronized Enumeration elements()
    {
    return CharIterator.begin( myArray, this );
    }

  /**
   * Return an iterator positioned at my first item.
   */
  public synchronized ForwardIterator start()
    {
    return CharIterator.begin( myArray, this );
    }

  /**
   * Return an iterator positioned immediately after my last item.
   */
  public synchronized ForwardIterator finish()
    {
    return CharIterator.end( myArray, this );
    }

  /**
   * Return the integer at the specified index as a Character object.
   * @param index The index.
   */
  public synchronized Object at( int index )
    {
    return new Character( myArray[index] );
    }

  /**
   * Set the object at a specified index.  The object must be a Character
   * @param index The index.
   * @param object The object to place at the specified index.
   * @exception java.lang.ClassCastException if object is not a Character
   * @exception java.lang.IndexOutOfBoundsException if object is not a Character
   */
  public synchronized void put( int index, Object object )
    {
    myArray[index] = ((Character)object).charValue();
    }
  }
