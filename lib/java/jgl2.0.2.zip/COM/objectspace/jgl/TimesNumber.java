// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * TimesNumber is a binary function that assumes that both of its operands are
 * instances of Number and returns the first operand multiplied by the second operand.
 * <p>
 * @see java.lang.Number
 * @see java.math.BigInteger
 * @see java.math.BigDecimal
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 */

public final class TimesNumber implements BinaryFunction
  {
  private Class mode;

  /**
   * Construct myself to use intValue() for operation.
   */
  public TimesNumber()
    {
    mode = new Integer( 0 ).getClass();
    }

  /**
   * Construct myself to operate on objects of the given class.  The class must
   * be derived from java.lang.Number.
   * @param discriminator The class of objects on which I will be operating.
   * @exception java.lang.IllegalArgumentException Throw if discriminator is not an instance of java.lang.Number.
   */
  public TimesNumber( Class discriminator )
    {
    if ( !NumberHelper.classNumber.isAssignableFrom( discriminator ) )
      throw new IllegalArgumentException( "discriminator must be an instance of java.lang.Number" );
    mode = discriminator;
    }

  /**
   * Return the result of multiplying the first operand by the second operand.
   * Be aware that some floating point conversions are not exact, and may
   * cause unexpected results due to rounding.
   * @param first The first operand, which must be an instance of Number.
   * @param second The second operand, which must be an instance of Number.
   * @exception COM.objectspace.jgl.InvalidOperationException Throw if I don't know how to interpret the values.
   * @return first * second
   */
  public Object execute( Object first, Object second )
    {
    return NumberHelper.multiply( (Number)first, (Number)second, mode );
    }
  }
