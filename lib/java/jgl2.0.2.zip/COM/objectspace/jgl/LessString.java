// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * LessString is a binary predicate that returns true
 * if the first operand as a string is less than the second operand
 * as a string.
 * <p>
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 */

public final class LessString implements BinaryPredicate
  {
  /**
   * Return true if the first operand is less than the second operand.
   * @return first.toString() < second.toString()
   */
  public boolean execute( Object first, Object second )
    {
    return first.toString().compareTo( second.toString() ) < 0;
    }
  }
