// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

/**
 * EqualTo is a binary predicate that returns true if the first operand
 * is equal to the second operand using the standard Java equals() method.
 * <p>
 * @see COM.objectspace.jgl.NotEqualTo
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 */

public final class EqualTo implements BinaryPredicate
  {
  /**
   * Compare two objects for equality.
   * @param first The first operand.
   * @param second The second operand.
   * @return true if the operands are equal according to the standard Java equals() method.
   */
  public boolean execute( Object first, Object second )
    {
    return first.equals( second );
    }
  }
