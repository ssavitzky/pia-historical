// Copyright(c) 1996,1997 ObjectSpace, Inc.
// Portions Copyright(c) 1995, 1996 Hewlett-Packard Company.

package COM.objectspace.jgl;

import java.util.Enumeration;

/**
 * ObjectArray allows a native array of Objects to be accessed like a Container.
 * It is particularly useful for applying generic algorithms like Sorting.sort()
 * to a native array.
 * <p>
 * @version 2.0.2
 * @author ObjectSpace, Inc.
 */

public class ObjectArray extends ArrayAdapter
  {
  Object myArray[];

  public ObjectArray()
    {
    myArray = new Object[ 0 ];
    }

  public ObjectArray( Object array[] )
    {
    synchronized( array )
      {
      myArray = array;
      }
    }

  public ObjectArray( ObjectArray array )
    {
    synchronized( array )
      {
      myArray = array.myArray;
      }
    }

  /**
   * Return a shallow copy of myself.
   */
  public synchronized Object clone()
    {
    return new ObjectArray( this );
    }

  /**
   * Return a string that describes me.
   */
  public synchronized String toString()
    {
    return Printing.toString( this, "Object[]" );
    }

  /**
   * Return true if I'm equal to a specified object.
   * @param object The object to compare myself against.
   * @return true if I'm equal to the specified object.
   */
  public boolean equals( Object object )
    {
    return Comparing.equal( this, (ObjectArray)object );
    }

  /**
   * Return the number of objects that I contain.
   */
  public int size()
    {
    return myArray.length;
    }

  /**
   * Return the maximum number of objects that I can contain.
   */
  public int maxSize()
    {
    return myArray.length;
    }

  /**
   * Return an Enumeration of my elements.
   */
  public synchronized Enumeration elements()
    {
    return ObjectIterator.begin( myArray, this );
    }

  /**
   * Return an iterator positioned at my first item.
   */
  public synchronized ForwardIterator start()
    {
    return ObjectIterator.begin( myArray, this );
    }

  /**
   * Return an iterator positioned immediately after my last item.
   */
  public synchronized ForwardIterator finish()
    {
    return ObjectIterator.end( myArray, this );
    }

  /**
   * Return the object at the specified index.
   * @param index The index.
   */
  public synchronized Object at( int index )
    {
    return myArray[ index ];
    }

  /**
   * Set the object at a specified index.  The object must be a Integer
   * @param index The index.
   * @param object The object to place at the specified index.
   * @exception java.lang.IndexOutOfBoundsException if index is not in range.
   */
  public synchronized void put( int index, Object object )
    {
    myArray[ index ] = object;
    }
  }
